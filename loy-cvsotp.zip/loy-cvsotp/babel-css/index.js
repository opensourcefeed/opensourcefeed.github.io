const cssDependencyMap = require("./cssDependency.json");

module.exports = function ({
    types: t
  }) {
    return {
      name: 'logger',
      visitor: {
        Program: {
          enter(path) {
            path.node.body.filter(b => b.type === "ImportDeclaration" && b.source && b.source.value.startsWith("loy-cvsotp")).forEach((b) => {
                b.specifiers.forEach((spec) => {
                    const imported = spec.imported;
                    if (imported) {
                        const componentsToImport = cssDependencyMap[imported.name];
                        componentsToImport && componentsToImport.forEach(comp => {
                            path.unshiftContainer('body', t.importDeclaration([], t.stringLiteral(`loy-cvsotp/es/lib/components/${comp}/index.css`)));
                        })
                    }
                })
            });
          }
        }
      }
    };
  }