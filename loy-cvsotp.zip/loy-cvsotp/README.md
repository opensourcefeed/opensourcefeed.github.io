# LOY-CVSOTP

Following SAA Design specification, loy-cvsotp is a React UI library which currently contains generic OTP component to use accross react applications.

App deployed on Kriscloud
Note: Only applications using Kriscloud's generic-appspec are able to consume loy-cvsotp

Ensure you have read access to loy-cvsotp repository. You could raise access on https://kriscloud.sq.com.sg for the role sia-auto LOY_CVSOTP_ADMIN if you do not have access.

Assume the role with access to loy-cvsotp repository. Run the command below to install as an optional dependency in your project.

npm install git+https://git-codecommit.ap-southeast-1.amazonaws.com/v1/repos/loy-cvsotp#v1.0.0 --save-optional

In SIA, we use Spark's pipeline for X-ray and SonarQube scanning. However, Spark's servers do not have access to Kriscloud CodeCommit. Steps 4-6 will be a workaround to solve this issue.

Add the following fallback-otp.js script into your project

try {
// check if loy-cvsotp exists in project
require.resolve("loy-cvsotp");
} catch (e) {
console.warn("loy-cvsotp is not found. Executing fallback-otp...");
var child_process = require("child_process");
child_process.execSync("npm install loy-cvsotp@npm:loy-cvsotp@^1.0.0", {stdio: [0, 1, 2] });
}

In your package.json, add the following script to execute the above code after installation.

"scripts": {
"postinstall": "node fallback-otp.js",
}

Make sure that the version of loy-cvsotp in fallback-otp.js and package.json are in sync.

Click here for further explanation on the steps above to consume loy-cvsotp on Kriscloud

App deployed on environment with access to Spark's artifactory
Ensure your local and deployed environment has access to Spark's artifactory

If yes, run the following command:

npm install loy-cvsotp --registry=https://artifactory.spark.sq.com.sg/artifactory/api/npm/npm-release/

Usage
Consumers need to import both the component and CSS to use it effectively

Importing React components
Example of importing InputBox component into MyComponent is shown below. Look under the Components section of this Storybook for the list of components.

import { OTPComponent } from 'loy-cvsotp';

export const MyComponent = () => {
const [value, setValue] = useState('');
const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
setValue(event.target.value);
};
return (

<div>
 <OTPComponent nonLoggedInData={nonLoggedData} />
</div>
);
};

Importing CSS

With BabelJS (recommended)
If you are using BabelJS in your projects, add the following plugin into your .babelrc. This plugin automatically imports the relevant CSS files into your project. The way it works is similar to babel-plugin-import by ant-design.

{
"plugins": ["loy-cvsotp/babel-css"]
}

Without BabelJS
If you are not using BabelJS or the plugin is not compatible with your project, you can import the CSS directly into your application. By importing this way, you will be loading all the CSS in loy-cvsotp, including the components you are not using.

import 'loy-cvsotp/es/index.css'
