export declare const basicInfoResponseEMAIL: {
    salutation: string;
    emailAddress: string;
    lastName: string;
    contactMode: string[];
};
export declare const basicInfoResponseError: {
    status: boolean;
    errorCode: string;
    errorMessage: string;
    errorType: string;
    otpErrorOnlyFlag: boolean;
    errorInTextBox: string;
};
export declare const generateOtpResponseEMAIL: {
    otpPrefix: string;
    status: boolean;
    customerContact: string;
    contactMode: string;
    errorCode: string;
    otpServiceDown: boolean;
    otpErrorOnlyFlag: boolean;
    errorType: string;
    errorInTextBox: string;
    sentViaSMSFlag: boolean;
    sentViaEMAILFlag: boolean;
    updateInfoFlag: boolean;
};
export declare const nonLoginResponse: {
    status: boolean;
    otpServiceDown: boolean;
    otpErrorOnlyFlag: boolean;
    errorType: string;
    errorInTextBox: string;
    sentViaSMSFlag: boolean;
    sentViaEMAILFlag: boolean;
    updateInfoFlag: boolean;
    customerContact: string;
    contactMode: string;
    otpPrefix: string;
    errorCode: string;
};
export declare const nonLoginResponseError: {
    status: boolean;
    otpServiceDown: boolean;
    otpErrorOnlyFlag: boolean;
    errorType: string;
    errorInTextBox: string;
    sentViaSMSFlag: boolean;
    sentViaEMAILFlag: boolean;
    updateInfoFlag: boolean;
    customerContact: string;
    contactMode: string;
    otpPrefix: string;
    errorCode: string;
};
export declare const verifyOTPResponse: {
    status: boolean;
    errorCode: string;
    errorMessage: string;
    errorType: string;
    otpErrorOnlyFlag: boolean;
    errorInTextBox: string;
};
export declare const loggedInData1: {
    customerId: string;
    deviceId: string;
    customerType: string;
    clientId: string;
    referralURL: string;
    locale: string;
    clientUUID: string;
};
export declare const nonLoggedInData1: {
    clientId: string;
    clientUUID: string;
    customerFamilyName: string;
    customerId: string;
    contactMode: string[];
    emailAddress: string;
    lastName: string;
    locale: string;
    mobileNumber: string;
    countryCode: string;
};
export declare const loggedInData2: {
    customerId: string;
    deviceId: string;
    customerType: string;
    clientId: string;
    referralURL: string;
    clientUUID: string;
};
export declare const nonLoggedInData2: {
    clientId: string;
    clientUUID: string;
    customerFamilyName: string;
    customerId: string;
    mobileNumber: string;
    contactMode: string[];
    countryCode: string;
    lastName: string;
    referralURL: string;
};
export declare const generateOtpResponseError: {
    otpPrefix: string;
    status: boolean;
    customerContact: string;
    contactMode: string;
    errorCode: string;
    otpServiceDown: boolean;
    otpErrorOnlyFlag: boolean;
    errorType: string;
    errorInTextBox: string;
    sentViaSMSFlag: boolean;
    sentViaEMAILFlag: boolean;
    updateInfoFlag: boolean;
};
export declare const verifyOTPResponseError: {
    status: boolean;
    errorCode: string;
    errorMessage: string;
    errorType: string;
    otpErrorOnlyFlag: boolean;
    errorInTextBox: string;
};
export declare const onOTPSubmit: (e: boolean) => boolean;
