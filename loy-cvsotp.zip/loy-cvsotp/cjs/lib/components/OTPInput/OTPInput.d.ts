interface OTPInputProps {
    arrayOfInputs: Array<string>;
    handleOnChange: (otp: Array<string>) => void;
    errorMessage?: string;
    isNumberInput?: boolean;
    enableError: (valid: boolean) => void;
}
export declare const OTPInput: (props: OTPInputProps) => JSX.Element;
export {};
