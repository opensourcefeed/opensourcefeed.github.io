import React from "react";
export interface ILightBoxProps {
    jsx: JSX.Element;
    width?: string;
    height?: string;
    showCloseBtn?: boolean;
    outSideClose?: boolean;
    closeButtonFunc?: {
        (): void;
    };
    preloader?: boolean;
    display?: boolean;
}
export declare const LightBox: React.ForwardRefExoticComponent<ILightBoxProps & React.RefAttributes<unknown>>;
