interface ShowMessageProps {
    errorType?: string;
    message?: string;
}
export declare const ShowMessage: (props: ShowMessageProps) => JSX.Element;
export {};
