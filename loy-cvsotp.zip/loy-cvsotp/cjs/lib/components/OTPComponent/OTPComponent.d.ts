export interface OTPComponentProps {
    loggedInData?: any;
    nonLoggedInData?: any;
    onSubmit?: (e: boolean) => void;
}
export declare const OTPComponent: (props: OTPComponentProps) => JSX.Element;
