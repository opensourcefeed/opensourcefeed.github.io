/// <reference types="react" />
interface LoginButtonProps {
    isEnabled: boolean;
    label: any;
    class?: string;
    preloader?: boolean;
    name?: string;
    lslserverDown?: boolean;
    captchalimit?: boolean;
}
export declare function LoginButton(props: LoginButtonProps): JSX.Element;
export {};
