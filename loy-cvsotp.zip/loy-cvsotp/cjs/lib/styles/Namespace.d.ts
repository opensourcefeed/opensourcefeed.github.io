export declare const OTPComponent: string;
export declare const LightBox: string;
export declare const LoginButton: string;
export declare const OTPInput: string;
export declare const ShowMessage: string;
