export interface IUserDataForOTP {
    clientId: string;
    clientUUID: string;
    countryCode: string;
    referralUrl?: string;
    locale?: string;
    customerId: string;
    deviceId?: string;
    deviceType?: string;
    contactOs?: string;
}
export interface INonLoggedInUserDataForOTP extends IUserDataForOTP {
    lastname: string;
    salutation?: string;
    mobileNumber?: string;
    emailAddress?: string;
    contactMode: Array<string>;
}
