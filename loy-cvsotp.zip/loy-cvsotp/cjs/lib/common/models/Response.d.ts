export interface response {
    status: string;
    code: string;
    message: string;
    data: {
        verified: string;
        challengeType: string;
        cvsKey: string;
        otp: string;
        salutation: string;
        emailAddress: string;
        mobileNumber: string;
        countryCode: string;
        lastName: string;
        contactMode: Array<string>;
        message?: string;
    };
}
interface ajaxResponse {
    status: boolean;
    errorCode: string;
    errorMessage: string;
    errorType: string;
    errorInTextBox: string;
}
export interface AjaxResponse extends ajaxResponse {
    status: boolean;
    errorCode: string;
    errorType: string;
    errorMessage: string;
    errorInTextBox: string;
}
export interface VerifyOTPAjaxRes extends ajaxResponse {
    status: boolean;
    errorCode: string;
    errorMessage: string;
    errorType: string;
    otpErrorOnlyFlag: boolean;
    errorInTextBox: string;
}
export interface SentOTPAjaxRes extends ajaxResponse {
    otpPrefix: string;
    status: boolean;
    customerContact: string;
    contactMode: string;
    errorCode: string;
    errorMessage: string;
    otpServiceDown: boolean;
    otpErrorOnlyFlag: boolean;
    errorType: string;
    errorInTextBox: string;
    sentViaSMSFlag: boolean;
    sentViaEMAILFlag: boolean;
    updateInfoFlag: boolean;
}
export {};
