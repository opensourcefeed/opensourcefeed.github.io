export declare enum COOKIE {
    CVS_LOGIN_COOKIE = "CVS_LOGIN_COOKIE",
    CVS_DATA = "CVSDATA",
    REMEMBER_ME_KF = "CVS_REMEMBER_ME_KF"
}
export declare enum USERTYPE {
    KF = "KF",
    TM = "TM",
    CT = "CT"
}
export declare enum OTPERRORMAPPER {
    SERVICE_DOWN = "COTPG0005, COTPG0008",
    NO_LIMIT_EXCEED_SENT = "COTPG0009",
    NO_LIMIT_EXCEED_VERIFY = "COTPV0008",
    EMAIL_OR_SMS_FAIL = "COTPG0019,COTPG0007",
    EMAIL_FAIL = "COTPG0098",
    SMS_FAIL = "COTPG0099",
    VERIFY_ERROR_IN_TEXT = "COTPV0009, COTPV0010",
    LOCK_AT_NEXT_ATTEMPT = "CVSLI0007",
    GENERICLOGINERROR = "CVSLI0006",
    PASSWORDMIGARTIONELIGIBILITY = "CVSLI0012",
    PLOCHANNEL2FA = "CVSLI0043",
    PROFILEDATA = "CSLAAA0000",
    ERROR_CANNOT_PROCESS = "CVSUI0000",
    SET_CAPTCHA_AFTER_LOGIN = "CVSLI0008",
    OTP_Resend_Mail = "ECOTPV0000",
    Otp_Resend_Sms = "SCOTPV0000",
    SEND_EMAIL_FAIL = "COTPG0019",
    SEND_SMS_FAIL = "COTPG0007"
}
export declare enum CONTACTMODE {
    EMAIL = "EMAIL",
    SMS = "SMS"
}
export declare enum Locale {
    de_DE = "de_DE",
    en_UK = "en_UK",
    es_ES = "es_ES",
    fr_FR = "fr_FR",
    in_ID = "in_ID",
    it_IT = "it_IT",
    ja_JP = "ja_JP",
    ko_KR = "ko_KR",
    nl_NL = "nl_NL",
    pt_BR = "pt_BR",
    ru_RU = "ru_RU",
    th_TH = "th_TH",
    vi_VN = "vi_VN",
    zh_CN = "zh_CN",
    zh_TW = "zh_TW"
}
