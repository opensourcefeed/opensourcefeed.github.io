export declare const env: "development" | "production" | "test";
interface Properties {
    ENDPOINTS: {
        BASICINFOURL: string;
        GENERATEOTPURL: string;
        NONLOGGEDURL: string;
        VERIFYOTP: string;
    };
}
declare const ServerProperties: Properties;
export { ServerProperties };
