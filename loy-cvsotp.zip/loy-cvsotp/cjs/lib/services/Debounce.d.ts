export default class Debouncer {
    private _dbtime;
    private _timestamp;
    constructor($ms: number);
    private getCurrentTime;
    tryBounce(): boolean;
}
