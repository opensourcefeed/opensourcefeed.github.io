import { Locale } from '../common';
export declare const otpHeader: Map<Locale, string>;
export declare const otpLabelSentBySMS: Map<Locale, string>;
export declare const otpLabelSentByEMAIL: Map<Locale, string>;
export declare const otpRendLabel: Map<Locale, string>;
export declare const otpServiceDownError: Map<Locale, string>;
export declare const labelverify: Map<Locale, string>;
