export declare function getUserProfile(userInfo: any): Promise<Response>;
export declare function generateOtp(contactMode: string, isResendOTP: boolean): Promise<Response>;
export declare function sentNonLoggedOTP(userInfo: any, isResendOtp: boolean, selectedContactMode: string): Promise<Response>;
export declare function verifyOTP(enteredOTP: any[], OTPType: string): Promise<Response>;
